#define COMPILATION_OPTIONS "echoping 6.0.2 compiled with x86_64-linux-gnu-gcc on generic (x86_64-pc-linux-gnu)\n at 2017-01-10 with options:\n\nHTTP: enabled\nICP: enabled\nOPENSSL: disabled \nGNUTLS: enabled\nSMTP: enabled\nLIBIDN: enabled\nTOS: enabled\nPRIORITY: enabled\n\nPlugins are searched in /usr/lib/echoping."

/* $Id: compilation.h.in 377 2007-03-12 20:48:05Z bortz $ */
